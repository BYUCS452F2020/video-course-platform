// Note: This class doesn't do anything right now, 
// but we can use it later on if we want to add 
// similar code between each of the request 
// classes. 
module.exports = 
  class Request {
    constructor() {}
  }