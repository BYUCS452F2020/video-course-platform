const DynamoUserDao =  require('../dao/dynamoDao/DynamoUserDao.js');
const SignUpResponse = require('../../shared/shared.js').SignUpResponse;

module.exports = 
  class AWSSignUpService {
    static signUpUser(signUpRequest) {
      let dao = new DynamoUserDao(); 
      let user = dao.createUser(signUpRequest.user, signUpRequest.password);
      return new SignUpResponse("Success", true, user); 
    }
  }