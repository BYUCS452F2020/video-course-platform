exports.handler = function(event, context, callback) {
  return callback(null, JSON.parse(event.body)); 
}